// OUTPUT TO SCREEN
console.log("Hello World");
console.log(3+4-20);

/* VARIABLE */
var x = 35;
var y = 35.22222;
var m = "sdfdf";
var n = true;

console.log(x);

//loosely typed languages
// javascript
//python
//php

//strongly typed languages
// java
// c/ c#, c++  

//typed/not typed

//dictionaries
var d = {
  "name" : "pritesh",
  "gpa" : 4.0,
  "id" : "C09341"
}
console.log(d);
console.log(d.name);

//array inside dictionaries

var d = {
  "name" :"pritesg",
  "id":"C09341",
  "courses": ["madt4114","madt4124","madt3104"]
  
}
console.log(d.name);
console.log(d.courses[2]);

var n = {
  "name" :"pritesg",
  "id"   :"C09341",
  "friend" : {"name":"marcos","pets":"dog","gpa":4.0
  }
}

//OUTPUT DOG TO THE SCREEN
//var x = d.friend;
//var y = x.pets;
//console.log(y);

//var x= d["friend"];
//var y = d["pets"];
//console.log(y);

//console.log(d.friend.pets);

var d = {
  "name":"pritesh",
  "id" : "C093491",
  "friend": {
    "name": "marcos",
    "pets": ["dog", "cat"],
    "grades" : {
      "4114":"A+",
      "4124":"C-"
    }
  },
  "food": {
    "pizza": {
      "1":"tomatos",
      "2":"chicken",
      "3":"salad"
    },
    "brunch":[83, 23, 14, 55]
  }
}

console.log(d.food.brunch[2]);
console.log(d.food.pizza["1"]);
console.log(d.friend.pets["1"]);
console.log(d.friend.grades["4124"]);
console.log(d.food.pizza["3"]);
console.log((90+65)/2);
var p={
      "A+":90,
      "C-":65
}
console.log((p[d.friend.grades["4114"]]+p[d.friend.grades["4124"]])/2);

//if statement in javascript
var x=25;
if(x<10){
  console.log("HELLO");
}
  else{
    console.log("GOODBYE");
  }
  
  //FOR LOOP
  var pokemon = ["pikachu", "squirtle", "ash"];
  for (var i=0; i < pokemon.length; i++) {
    console.log(pokemon[i] + "abc");
  }
  
  //FOR EACH
  
pokemon.forEach(function(x){
  console.log(x);
});

pokemon.forEach(function(x){
  console.log("HELLO");
  console.log("HELLO" + x);
});

// functions
function hello() {
  console.log("hello");
}

function nonsense() {
  console.log("bakwaas");
  console.log("voh lay");
  console.log("boba-gem!");
}

//USE THE function
nonsense();
nonsense();

function add(a, b, c, d) {
  console.log(a+b+c+d)
}

function abc() {
  return "hello";
}

add(3,5,6,4);

var m = abc();
console.log(m)

function palindrome(x) {
  x= ["eye"]
return true;
}
palindrome("eye");

//function palindrome(x) {
//  var x = ["a", "b", "c"];
 // for (var i=0; i < x.length; i--) {
 //   if(x)
  //  console.log("yes");
 // }
 // else {
 //   console.log("NO!");
 // }
//}

var ab = ["a", "b", "b", "a"];
var len = ab.length;

console.log(ab);

var check = false;

for(var i=0; i<len; i++)
{
  if(ab[i] == ab[len - (i+1)])
  {
    check =true;
    continue;
  }
  else{
    check = false;
    console.log("Array is not a palindrome");
    break;
  }
}
